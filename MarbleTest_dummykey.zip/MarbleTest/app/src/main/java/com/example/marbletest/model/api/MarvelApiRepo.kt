package com.example.marbletest.model.api

import androidx.compose.runtime.mutableStateOf
import com.example.marbletest.model.CharacterResult
import com.example.marbletest.model.CharactersApiResponse
import com.example.marbletest.model.NetworkResult
import kotlinx.coroutines.flow.MutableStateFlow
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MarvelApiRepo( private val api: MarvelApi ) {
    val characters = MutableStateFlow<NetworkResult<CharactersApiResponse>>( NetworkResult.Initial() )
    val characterDetails = mutableStateOf<CharacterResult?>(null)

    // 이걸 suspend로 쓰지 않는 것은 다소 의문이 간다.
    // 결국 Call back 으로 해결을 했다..
    fun query( query: String) {
        characters.value = NetworkResult.Loading()
        api.getCharacters(query)
            .enqueue(object: Callback<CharactersApiResponse> {
                override fun onResponse(
                    call: Call<CharactersApiResponse>,
                    response: Response<CharactersApiResponse>,
                ) {
                    if(response.isSuccessful) {
                        response.body()?.let {
                            characters.value = NetworkResult.Success( it )
                            println("kimdo isSuccessfull it $it")
                            println("kimdo isSuccessfull characters.value ${characters.value}")
                        }
                    } else {
                        println("kimdo not isSuccessfull")
                        characters.value = NetworkResult.Error(response.message())
                    }
                }

                override fun onFailure(call: Call<CharactersApiResponse>, t: Throwable) {
                    t.localizedMessage?.let {
                        characters.value = NetworkResult.Error( it )
                    }
                    t.printStackTrace()
                }

            })
    }

    fun getSingleCharacter(id: Int?) {
        id?.let {
            characterDetails.value = characters.value.data?.data?.results?.firstOrNull { character ->
                character.id == id
            }
        }
    }
}