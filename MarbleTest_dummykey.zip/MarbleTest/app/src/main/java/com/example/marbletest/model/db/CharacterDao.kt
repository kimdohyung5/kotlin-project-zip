package com.example.marbletest.model.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.marbletest.model.db.Constants.CHARACTER_TABLE
import kotlinx.coroutines.flow.Flow

@Dao
interface CharacterDao {
    @Query("select * from $CHARACTER_TABLE order by id asc")
    fun getCharacters(): Flow<List<DbCharacter>>

    @Query("select * from $CHARACTER_TABLE where id = :characterId")
    fun getCharacter(characterId: Int): Flow<DbCharacter>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun addCharacter(character: DbCharacter)

    @Update
    fun updateCharacter( character: DbCharacter)

    @Delete
    fun deleteCharacter( character: DbCharacter)

}