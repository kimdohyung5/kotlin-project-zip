package com.example.marbletest.model

data class Note(
    val characterId: Int,
    val title: String,
    val text: String
)
