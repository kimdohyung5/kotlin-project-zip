package com.example.marbletest

import ApiService
import android.content.Context
import androidx.room.Room
import com.example.marbletest.model.api.MarvelApiRepo
import com.example.marbletest.model.connectivity.ConnectivityMonitor
import com.example.marbletest.model.db.CharacterDao
import com.example.marbletest.model.db.CollectionDb
import com.example.marbletest.model.db.CollectionDbRepo
import com.example.marbletest.model.db.CollectionDbRepoImpl
import com.example.marbletest.model.db.Constants.DB
import com.example.marbletest.model.db.NoteDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.qualifiers.ApplicationContext

@Module
@InstallIn(ViewModelComponent::class )
class HiltModule {
    @Provides
    fun provideApiRepo(): MarvelApiRepo = MarvelApiRepo( ApiService.api )

    @Provides
    fun provideCollectionDb(@ApplicationContext context: Context): CollectionDb
        = Room.databaseBuilder(context, CollectionDb::class.java, DB).build()

    @Provides
    fun provideCharacterDao(collectionDb: CollectionDb) = collectionDb.characterDao()

    @Provides
    fun provideNoteDao(collectionDb: CollectionDb) = collectionDb.noteDao()

    @Provides
    fun provideDbRepoImpl(characterDao: CharacterDao, noteDao: NoteDao ): CollectionDbRepo =
        CollectionDbRepoImpl( characterDao, noteDao )



    @Provides
    fun provideConnectivityManager(@ApplicationContext context: Context) =
        ConnectivityMonitor.getInstance(context )
}