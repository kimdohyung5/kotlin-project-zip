package com.example.marbletest.model.db

object Constants {
    const val DB = "Comicsdb"
    const val CHARACTER_TABLE = "character_table"
    const val NOTE_TABLE = "note_table"
}