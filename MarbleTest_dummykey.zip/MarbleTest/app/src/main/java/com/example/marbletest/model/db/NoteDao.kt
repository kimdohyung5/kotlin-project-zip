package com.example.marbletest.model.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.marbletest.model.Note
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("select * from ${Constants.NOTE_TABLE} order by id")
    fun getAllNotes(): Flow<List<DbNote>>

    @Query("select * from ${Constants.NOTE_TABLE} where characterId = :characterId order by id asc")
    fun getNotes(characterId: Int ): Flow<List<DbNote>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun addNote(note:DbNote)

    @Update
    fun updateNote(note:DbNote)

    @Delete
    fun deleteNote(note:DbNote)

    @Query("delete from ${Constants.NOTE_TABLE} where characterId = :characterId")
    fun deleteAllNotes(characterId: Int)
}