package com.example.marbletest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.marbletest.model.NetworkResult
import com.example.marbletest.model.api.MarvelApiRepo
import com.example.marbletest.model.connectivity.ConnectivityMonitor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow

import kotlinx.coroutines.flow.debounce

import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repo: MarvelApiRepo,
    connectivityMonitor: ConnectivityMonitor
): ViewModel(){
    val result = repo.characters
    val queryText = MutableStateFlow("")
    private val queryInput = Channel<String>(Channel.CONFLATED)
    val characterDetails = repo.characterDetails
    val networkAvailable = connectivityMonitor

    init {
        retrieveCharacters()
    }

    private fun retrieveCharacters() {
        viewModelScope.launch(Dispatchers.IO) {
            queryInput.receiveAsFlow()
//                .filter {
//                validateQuery(it)
//            }
                .debounce(1000)
                .collect {
                    if( validateQuery(it)) {
                        println("kimdo retriveCharacters collect is called $it")
                        repo.query(it)
                    } else {
                        println("kimdo 단지 reset한다. ")
                        result.value = NetworkResult.Error("데이터를 입력해 주세요.")
                    }

                }

        }
    }

    private fun validateQuery(query: String) = query.length >= 2

    fun onQueryUpdate(input: String) {
        println("kimdo onQiueryUpdate $input")
        queryText.value = input
        queryInput.trySend(input)
    }

    fun retrieveSingleCharacter(id: Int) {
        repo.getSingleCharacter(id)
    }
}