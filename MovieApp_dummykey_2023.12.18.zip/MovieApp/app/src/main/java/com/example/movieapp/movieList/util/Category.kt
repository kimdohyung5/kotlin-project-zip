package com.example.movieapp.movieList.util

object Category {
    const val POPULAR = "popular"
    const val UPCOMING = "upcoming"
}