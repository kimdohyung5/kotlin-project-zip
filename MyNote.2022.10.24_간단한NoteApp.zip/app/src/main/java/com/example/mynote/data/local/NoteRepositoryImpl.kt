package com.example.mynote.data.local

import com.example.mynote.domain.NoteRepository
import com.example.mynote.domain.note.Note
import com.example.mynote.domain.time.DateTimeUtil
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class NoteRepositoryImpl constructor(
    private val db: NoteDatabase
): NoteRepository {
    private val dao = db.dao
    override suspend fun insertNote(note: Note) {
        dao.insertNote(
            NoteEntity(
                id = note.id,
                title = note.title,
                content = note.content,
                colorHex = note.colorHex,
                created = DateTimeUtil.toEpochMillis(note.created)
            )
        )
    }

    override suspend fun getNoteById(id: Long): Note? {
        return dao.getNoteById(id)?.toNote()
    }

    override fun getAllNotes(): Flow<List<Note>> {
        return dao.getAllNotes().map {  notes->
            notes.map { it.toNote() }
        }
    }

    override suspend fun deleteNoteById(id: Long) {
        dao.deleteNoteById(id)
    }
}