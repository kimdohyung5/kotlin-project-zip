package com.example.mynote.di

import android.app.Application
import androidx.room.Room
import com.example.mynote.data.local.NoteDatabase
import com.example.mynote.data.local.NoteRepositoryImpl
import com.example.mynote.domain.NoteRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton
    @Provides
    fun provideDatabase(application: Application): NoteDatabase {
        return Room.databaseBuilder(application, NoteDatabase::class.java, "notes.db").build()
    }


    @Singleton
    @Provides
    fun provideRepository(db: NoteDatabase): NoteRepository {
        return NoteRepositoryImpl(db)
    }
}