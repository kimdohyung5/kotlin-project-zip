package com.example.mynote.presentation

const val RedOrangeHex = 0xffffab91
const val RedPinkHex = 0xfff48fb1
const val BabyBlueHex = 0xff81deea
const val VioletHex = 0xffcf94da
const val LightGreenHex = 0xffe7ed9b