package com.example.mynote.domain

import com.example.mynote.domain.note.Note
import kotlinx.coroutines.flow.Flow

interface NoteRepository {

    suspend fun insertNote(note: Note)

    suspend fun getNoteById(id: Long): Note?

    fun getAllNotes(): Flow<List<Note>>

    suspend fun deleteNoteById(id: Long)
}