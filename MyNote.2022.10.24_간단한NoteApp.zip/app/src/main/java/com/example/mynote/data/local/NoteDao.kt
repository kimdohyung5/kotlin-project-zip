package com.example.mynote.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(noteEntity: NoteEntity)

    @Query("select * from notes where id = :id")
    suspend fun getNoteById(id: Long): NoteEntity?

    @Query("select * from notes ")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Query("delete from notes where id = :id")
    suspend fun deleteNoteById(id: Long)

}