package com.example.newstock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.newstock.presentation.company_info.CompanyInfoScreen
import com.example.newstock.presentation.company_listings.CompanyListingsScreen
import com.example.newstock.ui.theme.NewStockTheme
import com.example.newstock.util.Screen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NewStockTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = Screen.MainScreen.route ) {
                        composable(Screen.MainScreen.route) {
                            CompanyListingsScreen(navController = navController)
                        }
                        composable(Screen.DetailScreen.route + "/{symbol}") {
                            CompanyInfoScreen()
                        }
                    }
                }
            }
        }
    }
}

