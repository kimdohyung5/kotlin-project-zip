package com.example.newstock.data.remote.dto

data class IntradayInfoDto (
    val timestamp: String,
    val close: Double
)