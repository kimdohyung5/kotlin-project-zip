package com.example.newstock.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface  StockDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanyListings(
        companyListingEntities : List<CompanyListingEntity>
    )

    @Query("delete from companylistingentity")
    suspend fun clearCompanyListings()


    @Query(
        """
            select * from companylistingentity
            where lower(name) like '%' || lower(:query) || '%' OR
             upper(:query) == symbol
        """
    )
    suspend fun searchCompanyListing(query: String) : List<CompanyListingEntity>


}