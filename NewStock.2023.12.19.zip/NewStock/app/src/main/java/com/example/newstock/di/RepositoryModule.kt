package com.example.newstock.di

import com.example.newstock.data.csv.CSVParser
import com.example.newstock.data.csv.CompanyListingParser
import com.example.newstock.data.csv.IntradayInfoParser
import com.example.newstock.data.repository.StockRepositoryImpl
import com.example.newstock.domain.model.CompanyListing
import com.example.newstock.domain.model.IntradayInfo
import com.example.newstock.domain.repository.StockRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindCompanyListingsParser(
        companyListingsParser: CompanyListingParser
    ) : CSVParser<CompanyListing>

    @Binds
    @Singleton
    abstract fun bindIntradayInfoParser(
        intradayInfoParser: IntradayInfoParser
    ) : CSVParser<IntradayInfo>

    @Binds
    @Singleton
    abstract fun bindStockRepository (
        stockRepositoryImpl: StockRepositoryImpl
    ) : StockRepository

}